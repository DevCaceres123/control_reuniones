<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta content="" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="csrf-token" content="{{ csrf_token() }}">

<!-- App favicon -->
<link rel="shortcut icon" href="{{ asset('admin_template/images/logo_cruz.png') }}">
<link rel="stylesheet" href="{{ asset('admin_template/libs/jsvectormap/css/jsvectormap.min.css') }}">
<!-- App css -->
<link href="{{ asset('admin_template/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_template/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_template/css/app.min.css') }}" rel="stylesheet" type="text/css" />

<!-- Sweet Alert -->
<link href="{{ asset('admin_template/libs/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('admin_template/libs/animate.css/animate.min.css') }}" rel="stylesheet" type="text/css">


<link href="https://cdn.datatables.net/v/bs5/jszip-3.10.1/dt-2.1.7/b-3.1.2/b-colvis-3.1.2/b-html5-3.1.2/b-print-3.1.2/r-3.0.3/sb-1.8.0/sl-2.1.0/datatables.css" rel="stylesheet">

