<footer class="footer text-center text-sm-start d-print-none">
    <div class="container-xxl">
        <div class="row">
            <div class="col-12">
                <div class="card mb-0 rounded-bottom-0">
                    <div class="card-body">
                        <p class="text-muted mb-0">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <span class="text-muted d-none d-sm-inline-block float-end">
                                Dev. Mary Chipana
                            </span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
