<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class registro_lector extends Model
{
    protected $table = 'registro_lectores';
}
