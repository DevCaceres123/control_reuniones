<div class="startbar d-print-none">
    <!--start brand-->
    <div class="brand">
        <a href="" class="logo">
            <span>
                <img src="<?php echo e(asset('admin_template/images/logo_cruz.png')); ?>" alt="logo-small" class="logo-sm">
            </span>
            <span class="">

            </span>
        </a>
    </div>
    <!--end brand-->
    <!--start startbar-menu-->
    <div class="startbar-menu">
        <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
            <div class="d-flex align-items-start flex-column w-100">
                <!-- Navigation -->
                <ul class="navbar-nav mb-auto w-100">

                    <li class="menu-label pt-0 mt-0">
                        <span>MENU</span>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inicio.index')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('inicio')); ?>" role="button" aria-expanded="false"
                                aria-controls="sidebarDashboards">
                                <i class="iconoir-home-simple menu-icon"></i>
                                <span>INICIO</span>
                            </a>
                        </li><!--end nav-item-->
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.index')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#usuarios" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="usuarios">
                                <i class="iconoir-fingerprint-lock-circle menu-icon"></i>
                                <span>ADMIN USUARIOS</span>
                            </a>
                            <div class="collapse " id="usuarios">
                                <ul class="nav flex-column">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.usuario.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a>
                                        </li><!--end nav-item-->
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.rol.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">Roles</a>
                                        </li><!--end nav-item-->
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.permiso.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('permisos.index')); ?>">Permisos</a>
                                        </li><!--end nav-item-->
                                    <?php endif; ?>

                                </ul><!--end nav-->
                            </div><!--end startbarApplications-->
                        </li><!--end nav-item-->
                    <?php endif; ?>



                    <li class="menu-label mt-2">
                        <small class="label-border">
                            <div class="border_left hidden-xs"></div>
                            <div class="border_right"></div>
                        </small>
                        <span>ACTIVIDADES</span>
                    </li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reunion.index')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#reuniones" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="reuniones">
                                <i class="iconoir-community menu-icon"></i>
                                <span>REUNIONES</span>
                            </a>
                            <div class="collapse " id="reuniones">
                                <ul class="nav flex-column">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reunion.planificacion.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('reuniones.index')); ?>">Planificacion de
                                                Reuniones</a>
                                        </li>
                                    <?php endif; ?>

                                </ul><!--end nav-->
                            </div><!--end startbarApplications-->
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pago.index')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#pagos" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="pagos">
                                <i class="fas fa-money-bill menu-icon"></i>
                                <span>PAGOS</span>
                            </a>
                            <div class="collapse " id="pagos">
                                <ul class="nav flex-column">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pago.cuotas.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('pagarCuotas.index')); ?>">Cuotas</a>
                                        </li>
                                    <?php endif; ?>

                                </ul><!--end nav-->
                            </div><!--end startbarApplications-->
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reporte.index')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#reportes" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controreportes">
                                <i class="far fa-folder-open menu-icon"></i>
                                <span>REPORTES</span>
                            </a>
                            <div class="collapse " id="reportes">
                                <ul class="nav flex-column">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reporte.asistencia.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('asistencias.index')); ?>">Reporte de
                                                Asistencia</a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reporte.cuotas.inicio')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('cuotas.index')); ?>">Reporte de cuotas</a>
                                        </li>
                                    <?php endif; ?>
                                </ul><!--end nav-->
                            </div><!--end startbarApplications-->
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lector.inicio')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('lectores.index')); ?>" role="button" aria-expanded="false"
                                aria-controls="sidebarDashboards">
                                <i class="fas fa-desktop menu-icon"></i>
                                <span>LECTORES</span>
                            </a>
                        </li><!--end nav-item-->
                    <?php endif; ?>
                    
                </ul><!--end navbar-nav--->
            </div>
        </div><!--end startbar-collapse-->
    </div><!--end startbar-menu-->
</div>
<div class="startbar-overlay d-print-none"></div>
<?php /**PATH C:\xampp\htdocs\control_reuniones\resources\views/plantilla_admin/menu.blade.php ENDPATH**/ ?>