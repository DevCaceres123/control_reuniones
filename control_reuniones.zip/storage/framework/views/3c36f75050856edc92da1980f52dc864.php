<!DOCTYPE html>
<html lang="es" dir="ltr" data-startbar="light" data-bs-theme="light">

    <head>
        <title>ADMIN | <?php echo $__env->yieldContent('titulo'); ?></title>
        
        <?php echo $__env->make('plantilla_admin.estilos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('estilos'); ?>
    </head>

    <body>
        
        <?php echo $__env->make('plantilla_admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('plantilla_admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-wrapper">

            <div class="page-content">
                <div class="container-xxl">
                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>

                
                <?php echo $__env->make('plantilla_admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        
        <?php echo $__env->make('plantilla_admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>

</html>
<?php /**PATH C:\xampp\htdocs\control_reuniones\resources\views/principal.blade.php ENDPATH**/ ?>